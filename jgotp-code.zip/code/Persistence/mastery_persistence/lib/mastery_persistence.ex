#---
# Excerpted from "Designing Elixir Systems with OTP",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material,
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose.
# Visit http://www.pragmaticprogrammer.com/titles/jgotp for more book information.
#---
defmodule MasteryPersistence do
  import Ecto.Query, only: [from: 2]
  alias MasteryPersistence.{Response, Repo}

  def record_response(response, in_transaction \\ fn _response -> :ok end) do
    {:ok, result} = Repo.transaction(fn ->
      %{
        quiz_title: to_string(response.quiz_title),
        template_name: to_string(response.template_name),
        to: response.to,
        email: response.email,
        answer: response.answer,
        correct: response.correct,
        inserted_at: response.timestamp,
        updated_at: response.timestamp
      }
      |> Response.record_changeset
      |> Repo.insert!
      in_transaction.(response)
    end)
    result
  end

  def report(quiz_title) do
    quiz_title = to_string(quiz_title)
    from(
      r in Response,
      select: {r.email, count(r.id)},
      where: r.quiz_title == ^quiz_title,
      group_by: [r.quiz_title, r.email]
    )
    |> Repo.all
    |> Enum.into(Map.new)
  end
end
